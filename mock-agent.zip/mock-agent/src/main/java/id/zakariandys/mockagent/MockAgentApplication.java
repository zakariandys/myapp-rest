package id.zakariandys.mockagent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockAgentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MockAgentApplication.class, args);
	}

}
